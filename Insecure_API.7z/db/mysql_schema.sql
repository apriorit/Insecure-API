/* SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO"; */
/* SET AUTOCOMMIT = 0; */
/* START TRANSACTION; */
/* SET time_zone = "+00:00"; */

-- --------------------------------------------------------
--
-- Table structure for table `Task` generated from model 'Task'
-- Information about task
--

CREATE TABLE IF NOT EXISTS `Task` (
  `id` INTEGER PRIMARY KEY  NOT NULL AUTO_INCREMENT,
  `title` TEXT NOT NULL,
  `description` TEXT NOT NULL,
  `status` TEXT NOT NULL,
  `assignee` INTEGER NOT NULL
);

--
-- Table structure for table `User` generated from model 'User'
-- Information about registered user
--

CREATE TABLE IF NOT EXISTS `User` (
  `id` INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `username` TEXT NOT NULL,
  `photo` TEXT DEFAULT NULL,
  `first_name` TEXT DEFAULT NULL,
  `last_name` TEXT DEFAULT NULL,
  `email` TEXT NOT NULL,
  `position` TEXT DEFAULT NULL,
  `tasks` INTEGER DEFAULT 0,
  `password` TEXT,
  `user_type` TEXT DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS `BlockedTokens` (
  `id` INTEGER PRIMARY KEY  NOT NULL AUTO_INCREMENT,
  `token` TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS `ResetCode` (
  `id` INTEGER PRIMARY KEY  NOT NULL AUTO_INCREMENT,
  `email` TEXT NOT NULL,
  `code` TEXT NOT NULL
);
