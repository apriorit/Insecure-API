#!/usr/bin/env python3

import connexion

from swagger_server import encoder
from flask import g


def main():
    app = connexion.FlaskApp(__name__, specification_dir='./swagger/')
    app.app.json_encoder = encoder.JSONEncoder
    app.app.config.from_envvar('CONFIG_FILE')
    app.add_api('swagger.yaml', arguments={
                'title': 'Sample OWASP insecure API'}, pythonic_params=True)

    @app.app.teardown_appcontext
    def close_db(error):
        """Closes the database again at the end of the request."""
        if hasattr(g, 'db'):
            g.db.close()

    @app.app.route('/')
    def home():
        return "OK"

    app.run(port=8080)


if __name__ == '__main__':
    main()
