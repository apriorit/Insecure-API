from typing import List
from swagger_server import util
from flask import request
"""
controller generated to handled auth operation described at:
https://connexion.readthedocs.io/en/latest/security.html
"""


def check_bearerAuth(token):
    cursor = util.get_db().cursor()
    cursor.execute(
        "SELECT * FROM BlockedTokens WHERE token = '{}'".format(token))
    myresult = cursor.fetchall()
    if not myresult:
        return {'userid': util.decode_auth_token(token), 'token': token}
