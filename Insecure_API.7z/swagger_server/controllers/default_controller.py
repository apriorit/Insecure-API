import connexion
from flask.wrappers import Response
from json import dumps
import random
from swagger_server.models.body import Body  # noqa: E501
from swagger_server.models.body1 import Body1  # noqa: E501
from swagger_server.models.body2 import Body2  # noqa: E501
from swagger_server.models.body3 import Body3  # noqa: E501
from swagger_server.models.body4 import Body4  # noqa: E501
from swagger_server.models.task import Task  # noqa: E501
from swagger_server.models.user import User  # noqa: E501
from swagger_server import util
import flask
from flask import g, request

ADMIN_ID = 0


def error(message='Failed to process request', code=500):
    return Response(dumps({'message': message, 'code': code}), code)


def success(obj):
    return Response(dumps(obj), 200)


def not_found():
    return error('Not found', 404)


def unauthorized():
    return error('Unauthorized', 403)


def bad_request():
    return error('Bad request', 400)


def authenticated(func):
    def wrapped_function(*args, token_info={}, **kwargs):
        if not token_info or token_info['userid'] is None:
            return unauthorized()
        else:
            kwargs['user'] = token_info['userid']
            return func(*args, token=token_info['token'], **kwargs)

    return wrapped_function


def admin(func):
    def wrapped_function(*args, token_info={}, **kwargs):
        user_id = token_info['userid']

        cursor = util.get_db().cursor()
        cursor.execute("SELECT * FROM User WHERE id = {}".format(user_id))
        res = cursor.fetchall()
        created_user = User()
        if not res:
            created_user.user_type = 'user'
        else:
            created_user.from_dbo(res[0])

        if user_id == ADMIN_ID or created_user.user_type == 'admin':
            kwargs['user'] = user_id
            return func(*args, token=token_info['token'], **kwargs)
        else:
            return unauthorized()

    return wrapped_function


def assignee_or_admin(func):
    def wrapped_function(task_id, user=None, **kwargs):
        cursor = util.get_db().cursor()
        cursor.execute(
            "SELECT assignee FROM Task WHERE id = {}".format(task_id))
        task_info = cursor.fetchall()
        if not task_info:
            return not_found()

        if user == ADMIN_ID or task_info[0][0] == user:
            return func(task_id, user=user, **kwargs)

        return unauthorized()

    return wrapped_function


def exact_user(func):
    def wrapped_function(user_id, user=None, **kwargs):
        if user == ADMIN_ID or user_id == user:
            return func(user_id, user=user, **kwargs)

        return unauthorized()

    return wrapped_function


def get_task_response_with_user(task_id):
    cursor = util.get_db().cursor()
    cursor.execute(
        "SELECT id, title, description, status, assignee FROM Task WHERE id = {}".format(task_id))
    _id, title, description, status, assignee = cursor.fetchone()

    cursor.execute("SELECT * FROM User WHERE id = {}".format(assignee))
    res = cursor.fetchall()
    if not res:
        return not_found()
    created_user = User()
    created_user.from_dbo(res[0])

    return success({'id': _id, 'title': title, 'description': description, 'status': status, 'assignee': assignee,
                    'username': created_user.username, 'email': created_user.email, 'tasks': created_user.tasks,
                    'first_name': created_user.first_name, 'last_name': created_user.last_name, 'photo': created_user.photo,
                    'user_type': created_user.user_type})


def get_users():
    cursor = util.get_db().cursor()
    cursor.execute("SELECT * FROM User")
    res = cursor.fetchall()
    if not res:
        return not_found()

    output = []
    for key in res:
        created_user = User()
        created_user.from_dbo(key)
        output.append({'id': created_user.id, 'username': created_user.username, 'password': created_user.password,
                       'email': created_user._email, 'tasks': created_user.tasks, 'position': created_user.position,
                       'first_name': created_user.first_name, 'last_name': created_user.last_name, 'photo': created_user.photo,
                       'user_type': created_user.user_type})

    return success({'users': output})


def get_task_response(task_id):
    cursor = util.get_db().cursor()
    cursor.execute(
        "SELECT id, title, description, status, assignee FROM Task WHERE id = {}".format(task_id))
    _id, title, description, status, assignee = cursor.fetchone()

    return success({'id': _id, 'title': title, 'description': description, 'status': status, 'assignee': assignee})


def get_page_tasks(page, size):
    cursor = util.get_db().cursor()
    cursor.execute(
        "SELECT * FROM Task LIMIT {}, {}".format((page-1)*size, size))
    tasks = cursor.fetchall()
    if not tasks:
        return success({'tasks': []})

    output = []
    for task in tasks:
        created_task = Task()
        created_task.from_dbo(task)
        output.append({'id': created_task.id, 'title': created_task.title, 'description': created_task.description,
                       'status': created_task.status, 'assignee': created_task.assignee})

    return success({'tasks': output})


def get_user_by_id(user_id, token=None):
    cursor = util.get_db().cursor()
    cursor.execute("SELECT * FROM User WHERE id = {}".format(user_id))
    res = cursor.fetchall()
    if not res:
        return not_found()
    created_user = User()
    created_user.from_dbo(res[0])
    res = {'id': created_user.id, 'username': created_user.username, 'email': created_user.email, 'tasks': created_user.tasks,
           'first_name': created_user.first_name, 'last_name': created_user.last_name, 'photo': created_user.photo, 'user_type': created_user.user_type, 'token': token}
    if not res['token']:
        del res['token']
    return success(res)


def login_post(body=None):  # noqa: E501
    """Login with user credentials

     # noqa: E501

    :param body: Login request with username and password
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = connexion.request.get_json()  # noqa: E501

        cursor = util.get_db().cursor()

        if body['username'] == 'admin' and body['password'] == 'admin':
            return success({'username': 'admin', 'email': 'admin@example.com', 'token': util.encode_auth_token(ADMIN_ID)})

        cursor.execute(
            "SELECT * FROM User WHERE username = '{}'".format(body['username']))
        myresult = cursor.fetchall()
        if not myresult:
            return error('Invalid credentials provided', 403)
        user = User()
        user.from_dbo(myresult[0])
        if body['password'] == user.password:
            return get_user_by_id(user.id, token=util.encode_auth_token(user.id))
        else:
            return error('Invalid credentials provided', 403)


@authenticated
def logout_post(token=None, **kwargs):  # noqa: E501
    """Revoke access token

     # noqa: E501


    :rtype: None
    """
    cursor = util.get_db().cursor()

    cursor.execute(
        "INSERT INTO BlockedTokens (token) VALUES ('{}')".format(token))
    util.get_db().commit()
    return success({})


def reset_password_code_post(code, body=None):  # noqa: E501
    """Submit verification code for password reset

     # noqa: E501

    :param code: Numeric code to reset password for based on email
    :type code: int
    :param body: Email
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Body1.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()
        cursor.execute(
            "SELECT code FROM ResetCode WHERE email = '{}' ORDER BY id DESC".format(body.email))

        res = cursor.fetchall()
        if res and int(res[0][0]) == code:
            cursor.execute(
                "SELECT id FROM User WHERE email = '{}'".format(body.email))
            found_id = cursor.fetchone()
            if not found_id or not found_id[0]:
                return(error('Failed something', 500))

            new_password = util.random_gen(16)

            cursor.execute(
                "UPDATE User SET password = '{}' WHERE id = {}".format(new_password, found_id[0]))
            util.get_db().commit()
            return success({'password': new_password})
        else:
            return error('{}, {}, {}'.format(res[0], res and res[0] == code, code, 401))

    return bad_request()


def reset_password_post(**kwargs):  # noqa: E501
    """Request a password reset for email

     # noqa: E501

    :param body: Email
    :type body: dict | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = Body.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()
        cursor.execute(
            "SELECT * FROM User WHERE email = '{}'".format(body.email))
        if not cursor.fetchall():
            return error('No such user', 404)

        code = random.randint(1000, 9999)
        cursor.execute(
            "INSERT INTO ResetCode (email, code) VALUES ('{}', '{}')".format(body.email, code))
        util.get_db().commit()
        login = flask.current_app.config['SMTP_LOGIN']
        util.send_email(login, flask.current_app.config['SMTP_PASSWORD'], 'Password reset code', login, body.email, flask.current_app.config['SMTP_SERVER'], flask.current_app.config['SMTP_PORT'], '''
        <html>
        <body>
        <p>Here is your password reset code {}</p>
        </body>
        </html>
        '''.format(code))
        return success({})
    return bad_request()


def sign_up_post(body=None):  # noqa: E501
    """Register new user

     # noqa: E501

    :param body: Signup request
    :type body: dict | bytes

    :rtype: User
    """
    if connexion.request.is_json:
        user = User.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()

        cursor.execute(
            "SELECT * FROM User WHERE username = '{}' OR email = '{}'".format(user.username, user.email))
        if cursor.fetchall():
            return error('Such user already exists', 401)

        cursor.execute(
            "INSERT INTO User (username, email, password) VALUES ('{}', '{}', '{}')".format(user.username, user.email, user.password))
        util.get_db().commit()
        cursor = util.get_db().cursor()
        cursor.execute(
            "SELECT * FROM User WHERE username = '{}'".format(user.username))
        res = cursor.fetchall()
        created_user = User()
        created_user.from_dbo(res[0])
        return success({'id': created_user.id, 'username': created_user.username, 'email': created_user.email, 'tasks': created_user.tasks, 'user_type': 'user'})

    return bad_request()


@authenticated
def task_post(body=None, user=None, **kwargs):  # noqa: E501
    """Create new task

     # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: Task
    """
    if connexion.request.is_json:
        body = Task.from_dict(connexion.request.get_json())  # noqa: E501

        cursor = util.get_db().cursor()
        body.id = None
        if user != ADMIN_ID:
            body.assignee = user
        else:
            body.assignee = body.assignee if body.assignee else ADMIN_ID

        cursor.execute(
            "INSERT INTO Task (title, description, status, assignee) VALUES ('{}', '{}', '{}', {})".format(body.title, body.description, body.status, body.assignee))
        util.get_db().commit()

        return success({'id': cursor.lastrowid, 'title': body.title, 'description': body.description, 'status': body.status, 'assignee': body.assignee})

    return bad_request()


@authenticated
@assignee_or_admin
def task_task_id_assign_post(task_id, body=None, user=None, **kwargs):  # noqa: E501
    """Assign task to user

     # noqa: E501

    :param task_id: Numeric ID of the task to update assignee
    :type task_id: int
    :param body: 
    :type body: dict | bytes

    :rtype: Task
    """
    if user != ADMIN_ID:
        return error('Not allowed', 403)

    if connexion.request.is_json:
        body = connexion.request.get_json()
        cursor = util.get_db().cursor()

        cursor.execute(
            "UPDATE Task SET assignee = '{}' WHERE id = {}".format(body['assignee'], task_id))
        util.get_db().commit()
        return get_task_response(task_id)

    return bad_request()


@authenticated
@assignee_or_admin
def task_task_id_delete(task_id, **kwargs):  # noqa: E501
    """Delete task

     # noqa: E501

    :param task_id: Numeric ID of the task to update assignee
    :type task_id: int

    :rtype: None
    """

    cursor = util.get_db().cursor()
    cursor.execute("SELECT * FROM Task WHERE id = {}".format(task_id))
    if cursor.fetchall():
        cursor = util.get_db().cursor()
        cursor.execute("DELETE FROM Task WHERE id = {}".format(task_id))
        util.get_db().commit()
        return success({})

    return bad_request()


@authenticated
@assignee_or_admin
def task_task_id_get(task_id, **kwargs):  # noqa: E501
    """Get task by ID

     # noqa: E501

    :param task_id: Numeric ID of the task to update assignee
    :type task_id: int

    :rtype: Task
    """
    # return get_task_response(task_id)
    return get_task_response_with_user(task_id)


@authenticated
@assignee_or_admin
def task_task_id_put(task_id, **kwargs):  # noqa: E501
    """Update task

     # noqa: E501

    :param task_id: Numeric ID of the task to update assignee
    :type task_id: int
    :param body: 
    :type body: dict | bytes

    :rtype: Task
    """
    if connexion.request.is_json:
        body = Task.from_dict(connexion.request.get_json())
        cursor = util.get_db().cursor()

        cursor.execute(
            "UPDATE Task SET title = '{}', description = '{}', status = '{}' WHERE id = {}".format(body.title, body.description, body.status, task_id))
        util.get_db().commit()
        return get_task_response(task_id)

    return bad_request()


@authenticated
@assignee_or_admin
def task_task_id_status_post(task_id, body=None, **kwargs):  # noqa: E501
    """Update task status

     # noqa: E501

    :param task_id: Numeric ID of the task to update status
    :type task_id: int
    :param body: 
    :type body: dict | bytes

    :rtype: Task
    """
    if connexion.request.is_json:
        body = connexion.request.get_json()
        cursor = util.get_db().cursor()

        cursor.execute(
            "UPDATE Task SET status = '{}' WHERE id = {}".format(body['status'], task_id))
        util.get_db().commit()
        return get_task_response(task_id)

    return bad_request()


@admin
def user_post(body=None, **kwargs):  # noqa: E501
    """Create new user

    Create user # noqa: E501

    :param body: User creation request
    :type body: dict | bytes

    :rtype: User
    """

    if connexion.request.is_json:
        user = User.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()
        if not user.password:
            return error('Password is required', 400)

        if not user.user_type or user.user_type != 'admin':
            user.user_type = 'user'

        cursor.execute(
            "SELECT * FROM User WHERE username = '{}' OR email = '{}'".format(user.username, user.email))
        if cursor.fetchall():
            return error('Such user already exists', 401)

        cursor.execute(
            "INSERT INTO User (username, email, password, user_type) VALUES ('{}', '{}', '{}', '{}')".format(user.username, user.email, user.password, user.user_type))
        util.get_db().commit()
        cursor = util.get_db().cursor()
        cursor.execute(
            "SELECT * FROM User WHERE username = '{}'".format(user.username))
        res = cursor.fetchall()
        created_user = User()
        created_user.from_dbo(res[0])
        return success({'id': created_user.id, 'username': created_user.username, 'email': created_user.email, 'tasks': created_user.tasks, 'user_type': created_user.user_type})

    return bad_request()


@admin
def user_user_id_delete(user_id, **kwargs):  # noqa: E501
    """Delete user by ID

    Delete user # noqa: E501

    :param user_id: Numeric ID of the user
    :type user_id: int

    :rtype: None
    """

    cursor = util.get_db().cursor()
    cursor.execute("SELECT * FROM User WHERE id = {}".format(user_id))
    if cursor.fetchall():
        cursor = util.get_db().cursor()
        cursor.execute("DELETE FROM User WHERE id = {}".format(user_id))
        util.get_db().commit()
        return success({})
    else:
        return not_found()


@authenticated
def user_user_id_get(user_id, **kwargs):  # noqa: E501
    """Get user information by user id

     # noqa: E501

    :param user_id: Numeric ID of the user
    :type user_id: int

    :rtype: User
    """
    return get_user_by_id(user_id)


@authenticated
@exact_user
def user_user_id_put(user_id, body=None, user=None, **kwargs):  # noqa: E501
    """Update user information

    Update user # noqa: E501

    :param user_id: Numeric ID of the user
    :type user_id: int
    :param body: User creation request
    :type body: dict | bytes

    :rtype: User
    """
    if user != ADMIN_ID and user != user_id:
        return unauthorized()

    if connexion.request.is_json:
        body = User.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()
        cursor.execute("SELECT * FROM User WHERE id = {}".format(user_id))
        res = cursor.fetchall()
        if not res:
            return error('Not found {}'.format(user_id), 404)
        existing_user = User()
        existing_user.from_dbo(res[0])
        body.username = getattr(
            body, 'username', getattr(existing_user, 'username'))
        body.email = getattr(body, 'email', getattr(existing_user, 'email'))
        body.first_name = getattr(body, 'first_name', getattr(
            existing_user, 'first_name'))
        body.last_name = getattr(body, 'last_name', getattr(
            existing_user, 'last_name'))
        body.user_type = getattr(body, 'user_type', getattr(
            existing_user, 'user_type'))

        if body.user_type != 'admin':
            body.user_type = 'user'

        cursor.execute(
            "UPDATE User SET username = '{}', email = '{}', first_name = '{}', last_name = '{}', user_type = '{}' WHERE id = {}".format(
                body.username, body.email, body.first_name, body.last_name, body.user_type, user_id))
        util.get_db().commit()
        return get_user_by_id(user_id)
    return bad_request()


@authenticated
@exact_user
def user_user_id_upload_photo_post(user_id, body=None, **kwargs):  # noqa: E501
    """Update userpic URL

     # noqa: E501

    :param user_id: Numeric ID of the user to update photo
    :type user_id: int
    :param body: 
    :type body: dict | bytes

    :rtype: User
    """
    if connexion.request.is_json:
        body = Body2.from_dict(connexion.request.get_json())  # noqa: E501
        cursor = util.get_db().cursor()
        cursor.execute("SELECT * FROM User WHERE id = {}".format(user_id))
        res = cursor.fetchall()
        if not res:
            return not_found()
        created_user = User()
        created_user.from_dbo(res[0])
        created_user.photo = body.photo_url
        cursor.execute(
            "UPDATE User SET photo = '{}' WHERE id = {}".format(created_user.photo, user_id))
        util.get_db().commit()
        return get_user_by_id(user_id)
    return bad_request()


def admin_users_get(**kwargs):
    """Get all users information

     # noqa: E501
    :rtype: JSON users: [user,...]
    """
    return get_users()


def tasks_get(**kwargs):
    """get a page with the specified number of tasks

     # noqa: E501
    : rtype JSON tasks: [task,...]
    """

    if not (kwargs['page'] or kwargs['size']):
        return bad_request()

    return get_page_tasks(kwargs['page'], kwargs['size'])
